package com.example.lo.flyers;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class UploadDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_details);
    }
}
