package com.example.lo.flyers;

import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.firebase.client.Firebase;

public class Main2Activity extends AppCompatActivity {

    ImageButton btnCamera;
    Button uploadBtn;
    ImageView View;
    Firebase myFirebase;
    EditText field1, field2, field3;
    String strTime, strLocation, strDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btnCamera = findViewById(R.id.button);
        uploadBtn = findViewById(R.id.button3);
        View = findViewById(R.id.imageView);
        field1 = findViewById(R.id.plain_text_input);
        field2 = findViewById(R.id.plain_text_input2);
        field3 = findViewById(R.id.plain_text_input3);

        strTime = field1.getText().toString();
        strLocation = field2.getText().toString();
        strDetails = field3.getText().toString();

        myFirebase = new Firebase("https://flyers-f278b.firebaseio.com");

        btnCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, 0);
            }
        });

        uploadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                strTime = field1.getText().toString();
                strLocation = field2.getText().toString();
                strDetails = field3.getText().toString();


                Firebase myNewChild = myFirebase.child("Time");
                Firebase myNewChild2 = myFirebase.child("Location");
                Firebase myNewChild3 = myFirebase.child("Details");

                myNewChild.setValue(strTime);
                myNewChild2.setValue(strLocation);
                myNewChild3.setValue(strDetails);

                Intent intent = new Intent(Main2Activity.this, MainActivity.class);
                startActivity(intent);

            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        Bitmap bitmap = (Bitmap)data.getExtras().get("data");
        View.setImageBitmap(bitmap);
    }

}
