package com.example.lo.flyers;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class FlyerAdapter extends RecyclerView.Adapter<FlyerAdapter.FlyerViewHolder> {

    private Context context;
    private List<Upload> uploads;

    public FlyerAdapter(Context context, List<Upload> uploads) {
        this.context = context;
        this.uploads = uploads;
    }

    @NonNull
    @Override
    public FlyerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.flyer_cardview, parent, false);
        return new FlyerViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull FlyerViewHolder holder, int position) {
        Upload currentUpload = uploads.get(position);
        holder.textViewName.setText(currentUpload.getLocation());
        //Picasso is a library that makes image stuff a LOT easier
        //see on http://square.github.io/picasso/
        Picasso.get().load(currentUpload.getImageUrl()).fit().centerInside().into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return uploads.size();
    }

    public class FlyerViewHolder extends RecyclerView.ViewHolder {
        //THIS IS EVERYTHING THAT WILL BE DISPLAYED ON MAIN PAGE
        //ADD MORE IF YOU WANT
        public TextView textViewName;
        public ImageView imageView;

        public FlyerViewHolder(View flyerView) {
            super(flyerView);
            textViewName = flyerView.findViewById(R.id.title);
            imageView = flyerView.findViewById(R.id.image);



        }

    }
}
